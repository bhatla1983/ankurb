#!/bin/bash
chmod -R 750 ../*

#source ./var.sh

# echo $AWS_ACCESS_KEY_ID
# echo $AWS_SECRET_ACCESS_KEY
# echo $AWS_DEFAULT_REGION
cd ../terraform \
  && terraform get \
  && terraform validate \
  && terraform plan \
  && terraform apply \
  && echo "all worked" \
  || ( echo "did not work" ; exit 1) \
  && exit 0
