#!/bin/bash
export AWS_ACCESS_KEY_ID=`grep 'AWSAccessKeyId' ../../../access_secret_key.csv | awk -F "=" '{print $NF}'`
export AWS_SECRET_ACCESS_KEY=`grep 'AWSSecretKey' ../../../access_secret_key.csv | awk -F "=" '{print $NF}'`
export AWS_DEFAULT_REGION="eu-west-1"
